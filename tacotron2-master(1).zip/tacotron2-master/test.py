# -*- coding: utf-8 -*-
# @Time : 2023/11/10 17:15
# @Author : Python_Gt
# @File : test.py
from pydub import AudioSegment
from pydub.playback import play


def change_voice(file_path, output_path):
    # 加载音频文件
    sound = AudioSegment.from_file(file_path)

    # 降低音调（模拟男声）
    octaves_down = -1
    new_sound = sound._spawn(sound.raw_data, overrides={
        "frame_rate": int(sound.frame_rate * (2 ** octaves_down))
    })

    # 保存变声后的音频文件
    new_sound.export(output_path, format="wav")

    # 播放变声后的音频
    play(new_sound)


if __name__ == "__main__":
    input_file_path = "./OMG.wav"
    output_file_path = "male_voice.wav"

    try:
        change_voice(input_file_path, output_file_path)
    except PermissionError:
        pass
